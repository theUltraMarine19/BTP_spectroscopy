Description : This contains videos for the reconstruction results for each spectral band for the results (namely, Si, Si+GaN and Par) shown in the paper, and the spectral plots at missing pixels averaged across a 3X3 window around it which have been reconstructed (or filled in) by our algorithm.

Size : 20.2 MB(original)

Player information : Windows Media Player 12.0.17134.471 for videos. For best experience, use Movies & TV(Trusted Microsoft Store App) latest version. For spectral plots, use Photos App in Microsoft latest version.

Packing List :

Videos for original, partially sampled and reconstructed Raman spectral images for all spectral bands
=======================================================================================================

(1) Si_random_20%_Sampling, (2) Si_random_50%_Sampling, and (3) Si_random_80%_Sampling are videos for silicon corresponding to Fig. 1 that show reconstruction results for all 226 spectral bands for each of 20%, 50% and 80% sampling respectively

(4) paraffin_random_20%_Sampling, (5) paraffin_random_50%_Sampling, and (6) paraffin_random_80%_Sampling are videos for paraffin corresponding to Fig. 2 that show reconstruction results for all 208 spectral bands for each of 20%, 50% and 80% sampling respectively

(7) Si+GaN_random_20%_Sampling, (8) Si+GaN_random_50%_Sampling, and (9) Si+GaN_random_80%_Sampling are videos for silicon + gallium nitride corresponding to Fig. 4 that show reconstruction results for all 179 spectral bands for each of 20%, 50% and 80% sampling respectively

(10) Si_structural_every4thpixel_Sampling is the video for silicon corresponding to Fig. 3 that shows reconstruction results for all 226 spectral bands for sampling every 4th pixel in both directions
(11) paraffin_structural_every4thpixel_Sampling is the video for paraffin corresponding to Fig. 3 that shows reconstruction results for all 208 spectral bands for sampling every 4th pixel in both directions


Spectral plots averaged across 3 X 3 window in a neighbourhood of missing pixels
==================================================================================

(12) spectralPlot_Si_random_20%Sampling, (13) spectralPlot_Si_random_50%Sampling, (14) spectralPlot_Si_random_80%Sampling are the spectral plots for silicon at one of the missing pixels for each of 20%, 50% and 80% sampling respectively, corresponding to Fig. 1

(15) spectralPlot_paraffin_random_20%Sampling, (16) spectralPlot_paraffin_random_50%Sampling and (17) spectralPlot_paraffin_random_80%Sampling are the spectral plots for paraffin at one of the missing pixels for each of 20%, 50% and 80% sampling respectively, corresponding to Fig. 2

(18) spectralPlot_Si+GaN_random_20%Sampling, (19) spectralPlot_Si+GaN_random_50%Sampling and (20) spectralPlot_Si+GaN_random_80%Sampling are the spectral plots for silicon + gallium nitride at one of the missing pixels for each of 20%, 50% and 80% sampling respectively, corresponding to Fig. 4

(21) spectralPlot_paraffin_structural_every4thpixel_Sampling is the spectra plot for paraffin at a pixel whose intensity is not measured for sampling every 4th pixel in both directions corresponding to Fig. 3
(22) spectralPlot_Si_structural_every4thpixel_Sampling is the spectra plot for silicon at a pixel whose intensity is not measured for sampling every 4th pixel in both directions corresponding to Fig. 3

Contact Information : Arijit Pramanik (parijit10@gmail.com)
					  Ajit Rajwade (ajitvr@cse.iitb.ac.in)